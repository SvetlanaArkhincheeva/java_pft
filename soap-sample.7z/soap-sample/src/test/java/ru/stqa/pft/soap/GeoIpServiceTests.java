package ru.stqa.pft.soap;

import org.testng.annotations.Test;
import org.webservicex.net.GeoIP;
import org.webservicex.net.GeoIPService;

import static org.testng.Assert.assertEquals;


public class GeoIpServiceTests {

    @Test
    public void testMyIp() {
        GeoIP geoIP = new GeoIPService().getGeoIPServiceSoap12().getGeoIP("172.18.24.8");
        assertEquals(geoIP.getCountryCode(), "RUS");
}
}
